
export interface ProductData {
  product_id: string;
  category: string;
  subcategory: string;
  brand: string;
  color: string;
  size: string;
  material: string;
  season: string;
  gender: string;
  original_price: number;
  current_price: number;
  discount_percentage: number;
  units_sold: number;
  revenue: number;
  date: string;
  day_of_week: string;
  is_weekend: number;
  is_holiday_season: number;
  promotion_active: number;
  rating: number;
  number_of_reviews: number;
  stock_quantity: number;
  days_since_launch: number;
  competitor_price: number;
  website_views: number;
  cart_additions: number;
  return_rate: number;
}

export interface PredictionResult {
  predicted_price: number;
  predicted_units: number;
  predicted_revenue: number;
  confidence_score: number;
  price_sensitivity: { price: number; units: number; revenue: number }[];
}

export interface ModelMetrics {
  rmse_price: number;
  rmse_sales: number;
  training_rows: number;
  test_rows: number;
  features_count: number;
  training_time_ms: number;
  top_factors: { category: string; value: string; impact_units: number }[];
}

export interface CategoricalMap {
  [key: string]: { [value: string]: number }; // value -> { priceDiff, unitsDiff }
}
