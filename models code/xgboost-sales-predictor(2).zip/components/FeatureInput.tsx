import React, { useState } from 'react';
import { HelpCircle } from 'lucide-react';

interface FeatureInputProps {
  label: string;
  value: string | number;
  onChange: (val: string | number) => void;
  type?: 'text' | 'number' | 'select';
  options?: string[];
  placeholder?: string;
  min?: number;
  tooltip?: string;
}

export const FeatureInput: React.FC<FeatureInputProps> = ({
  label,
  value,
  onChange,
  type = 'text',
  options = [],
  placeholder = '',
  min,
  tooltip
}) => {
  const [showTooltip, setShowTooltip] = useState(false);

  return (
    <div className="flex flex-col space-y-1 relative">
      <div className="flex items-center space-x-2">
        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{label}</label>
        {tooltip && (
          <div 
            className="relative"
            onMouseEnter={() => setShowTooltip(true)}
            onMouseLeave={() => setShowTooltip(false)}
          >
            <HelpCircle className="w-3 h-3 text-slate-400 cursor-help hover:text-blue-500" />
            {showTooltip && (
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-48 p-2 bg-slate-800 text-white text-xs rounded shadow-lg z-50">
                {tooltip}
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-slate-800"></div>
              </div>
            )}
          </div>
        )}
      </div>
      
      {type === 'select' ? (
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="bg-white border border-slate-300 text-slate-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 shadow-sm"
        >
          <option value="">Select {label}</option>
          {options.map((opt) => (
            <option key={opt} value={opt}>{opt}</option>
          ))}
        </select>
      ) : (
        <input
          type={type}
          min={min}
          value={value}
          onChange={(e) => onChange(type === 'number' ? Number(e.target.value) : e.target.value)}
          placeholder={placeholder}
          className="bg-white border border-slate-300 text-slate-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 shadow-sm"
        />
      )}
    </div>
  );
};