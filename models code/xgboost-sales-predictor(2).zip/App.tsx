import React, { useState, useEffect, useCallback } from 'react';
import { 
  UploadCloud, 
  BrainCircuit, 
  RefreshCw, 
  TrendingUp, 
  DollarSign, 
  Package, 
  Activity,
  AlertCircle,
  Tag,
  BarChart2,
  Users,
  FileSpreadsheet,
  Download,
  FileText,
  Lightbulb,
  Snowflake,
  Sun,
  Save,
  Upload
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis,
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  Legend
} from 'recharts';

import { parseCSV, exportToCSV } from './utils/csvParser';
import { modelInstance } from './services/mlEngine';
import { getDataset, saveDataset, saveModelState, getModelState } from './services/db';
import { FeatureInput } from './components/FeatureInput';
import { ProductData, ModelMetrics, PredictionResult } from './types';

const TOOLTIPS = {
  brand: "The manufacturer of the product. Affects brand premium and perceived value.",
  category: "The high-level classification (e.g., Electronics, Clothing).",
  subcategory: "Specific product type (e.g., Headphones, T-Shirts).",
  material: "Primary material composition, influencing cost and durability.",
  gender: "Target demographic gender.",
  season: "Best selling season (e.g., Summer, Winter). Affects seasonality.",
  competitor_price: "The price of a similar product from a direct competitor.",
  rating: "Average customer rating (1-5 stars). Higher ratings boost sales.",
  reviews: "Total count of customer reviews. High counts indicate popularity.",
  promotion: "Is this item currently on a special sale or campaign?",
  msrp: "Original Manufacturer Suggested Retail Price. Sets the baseline value.",
  stock: "Current inventory count. Low stock might limit total sales volume.",
  sale_price: "The actual price you intend to sell at. Leave 0 to let AI optimize.",
};

const SAMPLE_TEMPLATE = [
  {
    brand: "ExampleBrand",
    category: "Clothing",
    subcategory: "T-Shirts",
    material: "Cotton",
    gender: "Unisex",
    season: "Summer",
    original_price: 29.99,
    competitor_price: 25.00,
    rating: 4.5,
    number_of_reviews: 120,
    stock_quantity: 500,
    promotion_active: 0,
    current_price: 0
  },
  {
    brand: "TechCorp",
    category: "Electronics",
    subcategory: "Headphones",
    material: "Plastic",
    gender: "Unisex",
    season: "All-Year",
    original_price: 199.99,
    competitor_price: 180.00,
    rating: 4.8,
    number_of_reviews: 850,
    stock_quantity: 50,
    promotion_active: 1,
    current_price: 175.00
  }
];

const getCurrentSeason = () => {
  const month = new Date().getMonth();
  if ([11, 0, 1].includes(month)) return { name: 'Winter', icon: Snowflake };
  if ([5, 6, 7].includes(month)) return { name: 'Summer', icon: Sun };
  return { name: 'Transition', icon: Activity };
};

const App: React.FC = () => {
  // State: Data
  const [trainingData, setTrainingData] = useState<ProductData[]>([]);
  const [testData, setTestData] = useState<ProductData[]>([]);
  
  // State: UI & Status
  const [loading, setLoading] = useState<boolean>(true);
  const [statusMessage, setStatusMessage] = useState<string>("Initializing...");
  const [isTrained, setIsTrained] = useState<boolean>(false);
  const [metrics, setMetrics] = useState<ModelMetrics | null>(null);
  const [activeTab, setActiveTab] = useState<'single' | 'batch'>('single');
  const [currentSeason] = useState(getCurrentSeason());

  // State: Batch
  const [batchResults, setBatchResults] = useState<any[]>([]);

  // State: Prediction
  const [predictionInputs, setPredictionInputs] = useState({
    brand: '',
    category: '',
    subcategory: '',
    material: '',
    gender: '',
    season: '',
    competitor_price: 0,
    rating: 0,
    number_of_reviews: 0,
    original_price: 100,
    current_price: 0,
    stock_quantity: 100,
    promotion_active: 0
  });
  const [predictionResult, setPredictionResult] = useState<PredictionResult | null>(null);

  // State: Dropdown options
  const [options, setOptions] = useState({
    categories: [] as string[],
    subcategories: [] as string[],
    brands: [] as string[],
    seasons: [] as string[],
    materials: [] as string[],
    genders: [] as string[]
  });

  // Initialization: Load persisted data
  useEffect(() => {
    const init = async () => {
      try {
        setStatusMessage("Loading persisted data...");
        const [train, test, modelState] = await Promise.all([
          getDataset('training'),
          getDataset('test'),
          getModelState()
        ]);

        if (train) {
          setTrainingData(train);
          populateOptions(train);
        }
        if (test) setTestData(test);
        
        if (modelState) {
          modelInstance.loadJSON(modelState.weights);
          setMetrics(modelState.metrics);
          setIsTrained(true);
        }
      } catch (err) {
        console.error("Failed to load persistence:", err);
      } finally {
        setLoading(false);
        setStatusMessage("Ready.");
      }
    };
    init();
  }, []);

  const populateOptions = (data: ProductData[]) => {
    setOptions({
      categories: modelInstance.getUniqueValues(data, 'category'),
      subcategories: modelInstance.getUniqueValues(data, 'subcategory'),
      brands: modelInstance.getUniqueValues(data, 'brand'),
      seasons: modelInstance.getUniqueValues(data, 'season'),
      materials: modelInstance.getUniqueValues(data, 'material'),
      genders: modelInstance.getUniqueValues(data, 'gender'),
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'train' | 'test') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setStatusMessage(`Parsing ${type} data...`);
    
    try {
      const data = await parseCSV(file);
      if (data.length === 0) {
        alert("No valid rows found in CSV. Please check the file format.");
        setStatusMessage("Upload failed.");
        setLoading(false);
        return;
      }

      if (type === 'train') {
        setTrainingData(data);
        populateOptions(data);
        await saveDataset('training', data);
      } else {
        setTestData(data);
        await saveDataset('test', data);
      }
      setStatusMessage(`Loaded ${data.length} rows for ${type}.`);
    } catch (err) {
      console.error(err);
      setStatusMessage("Error parsing CSV.");
    } finally {
      setLoading(false);
    }
  };

  const handleTrain = async () => {
    if (trainingData.length === 0 || testData.length === 0) {
      alert("Please upload both training and testing datasets.");
      return;
    }

    setLoading(true);
    setStatusMessage("Training model (Gradient Boosting Simulation)...");

    try {
      setTimeout(async () => {
        const results = await modelInstance.train(trainingData, testData);
        setMetrics(results);
        setIsTrained(true);
        await saveModelState(modelInstance.toJSON(), results);
        setLoading(false);
        setStatusMessage("Training Complete.");
      }, 100);
    } catch (err) {
      console.error(err);
      setLoading(false);
      setStatusMessage("Training Failed.");
    }
  };

  const handlePredict = () => {
    if (!isTrained) return;
    
    const input: Partial<ProductData> = {
      ...predictionInputs,
      original_price: Number(predictionInputs.original_price),
      current_price: Number(predictionInputs.current_price),
      competitor_price: Number(predictionInputs.competitor_price),
      rating: Number(predictionInputs.rating),
      number_of_reviews: Number(predictionInputs.number_of_reviews),
      stock_quantity: Number(predictionInputs.stock_quantity),
      promotion_active: Number(predictionInputs.promotion_active)
    };

    try {
      const res = modelInstance.predict(input);
      setPredictionResult(res);
    } catch (err) {
      console.error("Prediction error", err);
    }
  };

  const handleBatchUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !isTrained) return;

    setLoading(true);
    setStatusMessage("Processing Batch Predictions...");

    try {
      const rows = await parseCSV(file);
      const results = rows.map(row => {
        // Prepare input from row (ensure types)
        const input: Partial<ProductData> = {
          ...row,
          current_price: row.current_price !== undefined ? Number(row.current_price) : 0 // 0 means predict optimal
        };
        const pred = modelInstance.predict(input);
        return {
          ...row,
          predicted_optimal_price: pred.predicted_price,
          predicted_sales_units: pred.predicted_units,
          predicted_revenue: pred.predicted_revenue,
          confidence: pred.confidence_score
        };
      });
      setBatchResults(results);
      setStatusMessage(`Processed ${results.length} rows.`);
    } catch (err) {
      console.error("Batch error", err);
      setStatusMessage("Batch processing failed. Ensure CSV format is correct.");
    } finally {
      setLoading(false);
    }
  };

  const downloadBatchResults = () => {
    if (batchResults.length === 0) return;
    exportToCSV(batchResults, "xgboost_predictions.csv");
  };

  const downloadTemplate = () => {
    exportToCSV(SAMPLE_TEMPLATE, "batch_upload_template.csv");
  };

  const handleReset = () => {
    setIsTrained(false);
    setMetrics(null);
    setPredictionResult(null);
    setStatusMessage("Model reset. Ready to retrain.");
  };
  
  const handleDownloadModel = () => {
    if (!isTrained || !metrics) return;
    const modelState = modelInstance.toJSON();
    const payload = {
      weights: modelState,
      metrics: metrics,
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'sales_predictor_model.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleLoadModel = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setLoading(true);
    setStatusMessage("Loading model from file...");
    
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json.weights && json.metrics) {
          modelInstance.loadJSON(json.weights);
          setMetrics(json.metrics);
          setIsTrained(true);
          await saveModelState(json.weights, json.metrics);
          setStatusMessage("Model loaded successfully.");
        } else {
          alert("Invalid model file. JSON must contain 'weights' and 'metrics'.");
          setStatusMessage("Model load failed.");
        }
      } catch (err) {
        console.error(err);
        alert("Failed to parse model file.");
        setStatusMessage("Model load failed.");
      } finally {
        setLoading(false);
      }
    };
    reader.readAsText(file);
  };

  const updateInput = (key: keyof typeof predictionInputs, value: any) => {
    setPredictionInputs(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans pb-10">
      {/* Header */}
      <header className="bg-slate-900 text-white p-6 shadow-lg">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <BrainCircuit className="w-8 h-8 text-blue-400" />
            <div>
              <h1 className="text-2xl font-bold tracking-tight">XGBoost Sales Predictor</h1>
              <p className="text-slate-400 text-xs">Persistent In-Browser Engine</p>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2 text-slate-300 text-sm bg-slate-800 px-3 py-1 rounded-full border border-slate-700">
               <currentSeason.icon className="w-4 h-4 text-sky-400" />
               <span className="hidden md:inline">Current Season: <span className="text-white font-medium">{currentSeason.name}</span></span>
            </div>
            <div className={`flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-mono ${isTrained ? 'bg-green-900 text-green-300' : 'bg-slate-800 text-slate-400'}`}>
              <div className={`w-2 h-2 rounded-full ${isTrained ? 'bg-green-400 animate-pulse' : 'bg-slate-500'}`}></div>
              <span>{isTrained ? 'MODEL READY' : 'NO MODEL'}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto mt-8 px-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: Data & Training */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* File Upload */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <h2 className="font-semibold text-slate-700 flex items-center gap-2">
                <UploadCloud className="w-4 h-4" /> Data Ingestion
              </h2>
              <span className="text-xs text-slate-500">{trainingData.length > 0 ? `${(trainingData.length / 1000).toFixed(1)}k rows` : 'Empty'}</span>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Training Dataset</label>
                <input 
                  type="file" 
                  accept=".csv"
                  onChange={(e) => handleFileUpload(e, 'train')}
                  className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer"
                />
                {trainingData.length > 0 && <p className="text-xs text-green-600 mt-1">Data loaded & persisted.</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Testing Dataset</label>
                <input 
                  type="file" 
                  accept=".csv"
                  onChange={(e) => handleFileUpload(e, 'test')}
                  className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100 cursor-pointer"
                />
                 {testData.length > 0 && <p className="text-xs text-green-600 mt-1">Data loaded & persisted.</p>}
              </div>
            </div>
          </div>

          {/* Training Controls */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-4 border-b border-slate-100 bg-slate-50">
              <h2 className="font-semibold text-slate-700 flex items-center gap-2">
                <Activity className="w-4 h-4" /> Model Operations
              </h2>
            </div>
            <div className="p-6">
              {!isTrained ? (
                <div className="space-y-4">
                  <button
                    onClick={handleTrain}
                    disabled={loading || trainingData.length === 0}
                    className={`w-full py-3 px-4 rounded-lg flex items-center justify-center space-x-2 font-semibold transition-all
                      ${loading || trainingData.length === 0 
                        ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                        : 'bg-blue-600 text-white hover:bg-blue-700 shadow-md hover:shadow-lg transform hover:-translate-y-0.5'}`}
                  >
                    {loading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>{statusMessage}</span>
                      </>
                    ) : (
                      <>
                        <BrainCircuit className="w-4 h-4" />
                        <span>Train Model</span>
                      </>
                    )}
                  </button>
                  
                  <div className="relative flex py-2 items-center">
                     <div className="flex-grow border-t border-slate-200"></div>
                     <span className="flex-shrink-0 mx-2 text-xs text-slate-400 uppercase">OR Load Existing</span>
                     <div className="flex-grow border-t border-slate-200"></div>
                  </div>

                  <div className="w-full">
                    <label 
                      htmlFor="load-model-input"
                      className="w-full py-2 px-4 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 flex items-center justify-center space-x-2 text-sm font-medium transition-colors cursor-pointer"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Import Model JSON</span>
                    </label>
                    <input 
                      id="load-model-input"
                      type="file" 
                      accept=".json"
                      onChange={handleLoadModel}
                      className="hidden"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                    <p className="text-green-800 font-semibold mb-1">Model Ready</p>
                    <p className="text-xs text-green-600">Model is saved locally.</p>
                  </div>
                  
                  {metrics && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="bg-slate-50 p-2 rounded border border-slate-100">
                          <span className="block text-slate-400 text-xs">RMSE (Price)</span>
                          <span className="font-mono font-bold">${metrics.rmse_price.toFixed(2)}</span>
                        </div>
                        <div className="bg-slate-50 p-2 rounded border border-slate-100">
                          <span className="block text-slate-400 text-xs">RMSE (Sales)</span>
                          <span className="font-mono font-bold">{metrics.rmse_sales.toFixed(1)}</span>
                        </div>
                      </div>

                      {metrics.top_factors && metrics.top_factors.length > 0 && (
                        <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                           <h4 className="text-xs font-bold text-blue-800 mb-2 flex items-center gap-1">
                             <Lightbulb className="w-3 h-3" /> Learned Patterns
                           </h4>
                           <ul className="space-y-1">
                             {metrics.top_factors.map((f, i) => (
                               <li key={i} className="text-xs flex justify-between">
                                  <span className="text-slate-600 truncate max-w-[120px]">{f.value}</span>
                                  <span className={`font-mono font-medium ${f.impact_units > 0 ? 'text-green-600' : 'text-red-500'}`}>
                                    {f.impact_units > 0 ? '+' : ''}{Math.round(f.impact_units)}u
                                  </span>
                               </li>
                             ))}
                           </ul>
                        </div>
                      )}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <button
                      onClick={handleDownloadModel}
                      className="flex-1 py-2 px-4 rounded-lg bg-slate-800 text-white hover:bg-slate-700 flex items-center justify-center space-x-2 text-sm font-medium transition-colors"
                      title="Download Model JSON"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save</span>
                    </button>
                    <button
                      onClick={handleReset}
                      className="flex-1 py-2 px-4 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 flex items-center justify-center space-x-2 text-sm font-medium transition-colors"
                      title="Retrain Model"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>Retrain</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Prediction Interface */}
        <div className="lg:col-span-8 space-y-6">
          
          <div className={`bg-white rounded-xl shadow-lg border border-slate-200 transition-opacity duration-500 ${isTrained ? 'opacity-100' : 'opacity-50 pointer-events-none grayscale'}`}>
            
            {/* Tabs */}
            <div className="flex border-b border-slate-100">
              <button 
                onClick={() => setActiveTab('single')}
                className={`flex-1 py-4 text-center font-medium text-sm border-b-2 transition-colors ${activeTab === 'single' ? 'border-blue-500 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
              >
                Single Item Prediction
              </button>
              <button 
                onClick={() => setActiveTab('batch')}
                className={`flex-1 py-4 text-center font-medium text-sm border-b-2 transition-colors ${activeTab === 'batch' ? 'border-blue-500 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
              >
                Batch Processing (CSV)
              </button>
            </div>

            {/* SINGLE PREDICTION CONTENT */}
            {activeTab === 'single' && (
            <>
            <div className="p-6 space-y-6">
              
              {/* SECTION 1: Product Specs */}
              <div>
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Tag className="w-3 h-3" /> Product Specs
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FeatureInput 
                    label="Brand" 
                    type="select" 
                    options={['Select...', 'Unknown', ...options.brands]} 
                    value={predictionInputs.brand} 
                    onChange={(v) => updateInput('brand', v)}
                    tooltip={TOOLTIPS.brand}
                  />
                  <FeatureInput 
                    label="Category" 
                    type="select" 
                    options={['Select...', ...options.categories]} 
                    value={predictionInputs.category} 
                    onChange={(v) => updateInput('category', v)}
                    tooltip={TOOLTIPS.category}
                  />
                  <FeatureInput 
                    label="Subcategory" 
                    type="select" 
                    options={['Select...', ...options.subcategories]} 
                    value={predictionInputs.subcategory} 
                    onChange={(v) => updateInput('subcategory', v)}
                    tooltip={TOOLTIPS.subcategory}
                  />
                  <FeatureInput 
                    label="Material" 
                    type="select" 
                    options={['Select...', ...options.materials]} 
                    value={predictionInputs.material} 
                    onChange={(v) => updateInput('material', v)}
                    tooltip={TOOLTIPS.material}
                  />
                  <FeatureInput 
                    label="Gender" 
                    type="select" 
                    options={['Select...', ...options.genders]} 
                    value={predictionInputs.gender} 
                    onChange={(v) => updateInput('gender', v)}
                    tooltip={TOOLTIPS.gender}
                  />
                  <FeatureInput 
                    label="Season" 
                    type="select" 
                    options={['Select...', ...options.seasons]} 
                    value={predictionInputs.season} 
                    onChange={(v) => updateInput('season', v)}
                    tooltip={TOOLTIPS.season}
                  />
                </div>
              </div>

              <div className="border-t border-slate-100 my-4"></div>

              {/* SECTION 2: Market Context */}
              <div>
                 <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Users className="w-3 h-3" /> Market Context
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <FeatureInput 
                    label="Competitor Price ($)" 
                    type="number" 
                    min={0}
                    value={predictionInputs.competitor_price} 
                    onChange={(v) => updateInput('competitor_price', v)}
                    tooltip={TOOLTIPS.competitor_price}
                  />
                  <FeatureInput 
                    label="Rating (1-5)" 
                    type="number" 
                    min={0}
                    value={predictionInputs.rating} 
                    onChange={(v) => updateInput('rating', v)}
                    tooltip={TOOLTIPS.rating}
                  />
                  <FeatureInput 
                    label="Review Count" 
                    type="number" 
                    min={0}
                    value={predictionInputs.number_of_reviews} 
                    onChange={(v) => updateInput('number_of_reviews', v)}
                    tooltip={TOOLTIPS.reviews}
                  />
                   <FeatureInput 
                    label="Promotion Active" 
                    type="select" 
                    options={['No', 'Yes']}
                    value={predictionInputs.promotion_active === 1 ? 'Yes' : 'No'} 
                    onChange={(v) => updateInput('promotion_active', v === 'Yes' ? 1 : 0)}
                    tooltip={TOOLTIPS.promotion}
                  />
                </div>
              </div>

              <div className="border-t border-slate-100 my-4"></div>

              {/* SECTION 3: Pricing */}
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <DollarSign className="w-3 h-3" /> Pricing Strategy
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FeatureInput 
                    label="Original MSRP ($)" 
                    type="number" 
                    min={0}
                    value={predictionInputs.original_price} 
                    onChange={(v) => updateInput('original_price', v)}
                    tooltip={TOOLTIPS.msrp}
                  />
                  <FeatureInput 
                    label="Stock Quantity" 
                    type="number" 
                    min={0}
                    value={predictionInputs.stock_quantity} 
                    onChange={(v) => updateInput('stock_quantity', v)}
                    tooltip={TOOLTIPS.stock}
                  />
                  <div className="md:col-span-1">
                     <FeatureInput 
                      label="Your Sale Price ($)" 
                      type="number" 
                      placeholder="0 = Auto Predict"
                      value={predictionInputs.current_price} 
                      onChange={(v) => updateInput('current_price', v)}
                      tooltip={TOOLTIPS.sale_price}
                    />
                    <p className="text-[10px] text-slate-400 mt-1">Leave 0 to let AI suggest optimal price.</p>
                  </div>
                </div>
              </div>

            </div>

            <div className="px-6 pb-6">
              <button 
                onClick={handlePredict}
                className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold text-lg hover:bg-slate-800 shadow-xl shadow-blue-900/10 transition-transform active:scale-[0.99] flex justify-center items-center gap-2"
              >
                <BarChart2 className="w-5 h-5" />
                Run Prediction
              </button>
            </div>
            </>
            )}

            {/* BATCH PREDICTION CONTENT */}
            {activeTab === 'batch' && (
              <div className="p-8 text-center space-y-6">
                <div className="border-2 border-dashed border-slate-200 rounded-xl p-10 flex flex-col items-center justify-center bg-slate-50">
                   <FileSpreadsheet className="w-12 h-12 text-slate-400 mb-4" />
                   <h3 className="text-lg font-medium text-slate-700">Batch Process CSV</h3>
                   <p className="text-sm text-slate-500 mb-4 max-w-sm">Upload a CSV containing multiple product rows. The model will append <code className="bg-slate-100 px-1 rounded">predicted_price</code> and <code className="bg-slate-100 px-1 rounded">predicted_sales</code> columns.</p>
                   
                   {/* Template Instruction Section */}
                   <div className="w-full max-w-md bg-blue-50 border border-blue-100 rounded-lg p-4 mb-6 text-sm text-blue-900">
                      <div className="flex items-start gap-2 text-left mb-3">
                         <FileText className="w-4 h-4 mt-0.5 shrink-0 text-blue-500" />
                         <div>
                            <p className="font-semibold mb-1">Required CSV Headers:</p>
                            <p className="text-xs font-mono text-blue-700 leading-relaxed break-words">
                              brand, category, subcategory, material, gender, season, original_price, competitor_price, rating, number_of_reviews, stock_quantity, promotion_active, current_price
                            </p>
                            <p className="text-xs text-blue-400 mt-1 italic">Note: Set `current_price` to 0 for auto-prediction.</p>
                         </div>
                      </div>
                      <button 
                        onClick={downloadTemplate}
                        className="w-full bg-white border border-blue-200 text-blue-600 hover:bg-blue-50 hover:text-blue-700 font-semibold py-2 px-4 rounded text-xs flex items-center justify-center gap-2 transition-colors"
                      >
                         <Download className="w-3 h-3" />
                         Download Sample CSV Template
                      </button>
                   </div>

                   <input 
                    type="file" 
                    accept=".csv"
                    onChange={handleBatchUpload}
                    className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer max-w-xs mx-auto"
                   />
                </div>

                {batchResults.length > 0 && (
                  <div className="animate-in fade-in slide-in-from-bottom-2">
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="font-bold text-slate-700">Preview ({batchResults.length} rows)</h4>
                      <button 
                        onClick={downloadBatchResults}
                        className="bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 hover:bg-green-700 shadow-md"
                      >
                        <Download className="w-4 h-4" /> Download Results
                      </button>
                    </div>
                    <div className="overflow-x-auto border border-slate-200 rounded-lg">
                      <table className="w-full text-sm text-left text-slate-500">
                        <thead className="text-xs text-slate-700 uppercase bg-slate-50">
                          <tr>
                            <th className="px-4 py-3">Brand</th>
                            <th className="px-4 py-3">Category</th>
                            <th className="px-4 py-3">Predicted Price</th>
                            <th className="px-4 py-3">Predicted Units</th>
                            <th className="px-4 py-3">Revenue</th>
                          </tr>
                        </thead>
                        <tbody>
                          {batchResults.slice(0, 5).map((row, idx) => (
                            <tr key={idx} className="bg-white border-b hover:bg-slate-50">
                              <td className="px-4 py-3">{row.brand}</td>
                              <td className="px-4 py-3">{row.category}</td>
                              <td className="px-4 py-3 font-bold text-blue-600">${row.predicted_optimal_price}</td>
                              <td className="px-4 py-3 text-emerald-600">{row.predicted_sales_units}</td>
                              <td className="px-4 py-3">${row.predicted_revenue}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    <p className="text-xs text-slate-400 mt-2 text-left">Showing first 5 rows.</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Results Display (Single Mode Only) */}
          {activeTab === 'single' && predictionResult && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Financial Outlook */}
              <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 text-white">
                  <h3 className="font-bold flex items-center gap-2">
                    <DollarSign className="w-5 h-5" /> Financial Outlook
                  </h3>
                </div>
                <div className="p-6 grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-slate-500 text-sm">Suggested Price</p>
                    <p className="text-3xl font-bold text-slate-800">${predictionResult.predicted_price}</p>
                    {predictionInputs.current_price === 0 && (
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">AI Optimal</span>
                    )}
                  </div>
                  <div>
                    <p className="text-slate-500 text-sm">Est. Revenue</p>
                    <p className="text-3xl font-bold text-indigo-600">${predictionResult.predicted_revenue.toLocaleString()}</p>
                  </div>
                  <div className="col-span-2 pt-4 border-t border-slate-100">
                     <div className="flex justify-between items-center mb-1">
                        <span className="text-xs font-semibold text-slate-500">Confidence Score</span>
                        <span className="text-xs font-bold text-slate-700">{(predictionResult.confidence_score * 100).toFixed(0)}%</span>
                     </div>
                     <div className="w-full bg-slate-200 rounded-full h-2">
                        <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${predictionResult.confidence_score * 100}%` }}></div>
                     </div>
                  </div>
                </div>
              </div>

              {/* Volume Forecast */}
              <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
                 <div className="bg-gradient-to-r from-emerald-500 to-teal-600 p-4 text-white">
                  <h3 className="font-bold flex items-center gap-2">
                    <Package className="w-5 h-5" /> Volume Forecast
                  </h3>
                </div>
                <div className="p-6">
                   <div className="flex items-end space-x-2 mb-4">
                      <p className="text-5xl font-bold text-slate-800">{predictionResult.predicted_units}</p>
                      <p className="text-slate-500 font-medium mb-2">units sold</p>
                   </div>
                   
                   {/* Seasonal Warning */}
                   {predictionInputs.season && 
                    currentSeason.name !== 'Transition' && 
                    predictionInputs.season.toLowerCase().includes(currentSeason.name === 'Winter' ? 'summer' : 'winter') && (
                      <div className="flex items-center gap-2 text-xs bg-amber-50 text-amber-800 p-2 rounded border border-amber-200 mb-2">
                        <AlertCircle className="w-4 h-4" />
                        <span>Off-Season Penalty Applied ({predictionInputs.season} in {currentSeason.name})</span>
                      </div>
                    )
                   }

                   <div className="h-32 w-full mt-4">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={[
                          { name: 'Avg', val: modelInstance['baseUnits'] || 50 },
                          { name: 'Pred', val: predictionResult.predicted_units }
                        ]}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="name" tick={{fontSize: 12}} />
                          <Tooltip />
                          <Bar dataKey="val" fill="#10b981" radius={[4, 4, 0, 0]} barSize={40} />
                        </BarChart>
                      </ResponsiveContainer>
                   </div>
                </div>
              </div>
            </div>

            {/* Price Sensitivity Chart */}
            <div className="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
                <div className="bg-slate-50 p-4 border-b border-slate-100 flex justify-between items-center">
                   <h3 className="font-bold text-slate-700 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-blue-500" /> Price Sensitivity Analysis
                   </h3>
                   <span className="text-xs text-slate-400">Projected Revenue vs Price</span>
                </div>
                <div className="p-6 h-64">
                   <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={predictionResult.price_sensitivity}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis 
                          dataKey="price" 
                          tick={{fontSize: 12}} 
                          label={{ value: 'Price ($)', position: 'insideBottom', offset: -5, fontSize: 10 }}
                        />
                        <YAxis 
                          yAxisId="left" 
                          tick={{fontSize: 12}}
                          label={{ value: 'Revenue ($)', angle: -90, position: 'insideLeft', fontSize: 10 }} 
                        />
                        <YAxis 
                          yAxisId="right" 
                          orientation="right" 
                          tick={{fontSize: 12}}
                          label={{ value: 'Units', angle: 90, position: 'insideRight', fontSize: 10 }}
                        />
                        <Tooltip 
                          formatter={(value: any, name: string) => [
                            name === 'revenue' ? `$${value}` : value, 
                            name === 'revenue' ? 'Rev' : 'Units'
                          ]}
                          labelFormatter={(label) => `Price: $${label}`}
                        />
                        <Legend />
                        <Line yAxisId="left" type="monotone" dataKey="revenue" stroke="#4f46e5" strokeWidth={2} name="Revenue" dot={{r: 4}} />
                        <Line yAxisId="right" type="monotone" dataKey="units" stroke="#10b981" strokeWidth={2} name="Units Sold" strokeDasharray="5 5" dot={{r: 3}} />
                      </LineChart>
                   </ResponsiveContainer>
                   <p className="text-xs text-center text-slate-400 mt-2">
                     Chart shows estimated revenue and sales volume at different price points relative to the selected price.
                   </p>
                </div>
            </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;