import { ProductData, ModelMetrics } from '../types';

const DB_NAME = 'XGBoostSalesDB';
const DB_VERSION = 1;

export const initDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('datasets')) {
        db.createObjectStore('datasets');
      }
      if (!db.objectStoreNames.contains('model')) {
        db.createObjectStore('model');
      }
    };
  });
};

export const saveDataset = async (key: 'training' | 'test', data: ProductData[]) => {
  const db = await initDB();
  return new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(['datasets'], 'readwrite');
    const store = transaction.objectStore('datasets');
    const request = store.put(data, key);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
};

export const getDataset = async (key: 'training' | 'test'): Promise<ProductData[] | undefined> => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(['datasets'], 'readonly');
    const store = transaction.objectStore('datasets');
    const request = store.get(key);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

export const saveModelState = async (state: any, metrics: ModelMetrics) => {
  const db = await initDB();
  return new Promise<void>((resolve, reject) => {
    const transaction = db.transaction(['model'], 'readwrite');
    const store = transaction.objectStore('model');
    store.put(state, 'weights');
    store.put(metrics, 'metrics');
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
};

export const getModelState = async () => {
  const db = await initDB();
  return new Promise<{weights: any, metrics: ModelMetrics} | null>((resolve, reject) => {
    const transaction = db.transaction(['model'], 'readonly');
    const store = transaction.objectStore('model');
    
    const weightsReq = store.get('weights');
    const metricsReq = store.get('metrics');
    
    transaction.oncomplete = () => {
      if (weightsReq.result && metricsReq.result) {
        resolve({ weights: weightsReq.result, metrics: metricsReq.result });
      } else {
        resolve(null);
      }
    };
    transaction.onerror = () => reject(transaction.error);
  });
};
