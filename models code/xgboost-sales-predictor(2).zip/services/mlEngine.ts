import { ProductData, CategoricalMap, PredictionResult, ModelMetrics } from '../types';

/**
 * Enhanced "BrowserXGB" Simulator.
 */

export class BrowserModel {
  // Feature Weights (The "Model")
  private categoryWeights: CategoricalMap = {};
  private subcategoryWeights: CategoricalMap = {};
  private brandWeights: CategoricalMap = {};
  private seasonWeights: CategoricalMap = {};
  private materialWeights: CategoricalMap = {};
  private genderWeights: CategoricalMap = {};
  
  // Baselines
  private basePrice: number = 0;
  private baseUnits: number = 0;
  private isTrained: boolean = false;

  // Persistence methods
  public toJSON() {
    return {
      categoryWeights: this.categoryWeights,
      subcategoryWeights: this.subcategoryWeights,
      brandWeights: this.brandWeights,
      seasonWeights: this.seasonWeights,
      materialWeights: this.materialWeights,
      genderWeights: this.genderWeights,
      basePrice: this.basePrice,
      baseUnits: this.baseUnits,
      isTrained: this.isTrained
    };
  }

  public loadJSON(data: any) {
    if (!data) return;
    this.categoryWeights = data.categoryWeights || {};
    this.subcategoryWeights = data.subcategoryWeights || {};
    this.brandWeights = data.brandWeights || {};
    this.seasonWeights = data.seasonWeights || {};
    this.materialWeights = data.materialWeights || {};
    this.genderWeights = data.genderWeights || {};
    this.basePrice = data.basePrice || 0;
    this.baseUnits = data.baseUnits || 0;
    this.isTrained = data.isTrained || false;
  }

  public async train(
    trainingData: ProductData[], 
    testData: ProductData[]
  ): Promise<ModelMetrics> {
    const startTime = performance.now();
    
    // Simulate async heavy lifting
    await new Promise(resolve => setTimeout(resolve, 800));

    // 1. Calculate Global Baselines
    let totalPrice = 0;
    let totalUnits = 0;
    const count = trainingData.length;

    const catStats: Record<string, any> = {};
    const subcatStats: Record<string, any> = {};
    const brandStats: Record<string, any> = {};
    const seasonStats: Record<string, any> = {};
    const materialStats: Record<string, any> = {};
    const genderStats: Record<string, any> = {};

    for (let i = 0; i < count; i++) {
      const row = trainingData[i];
      totalPrice += row.current_price;
      totalUnits += row.units_sold;

      this.updateStat(catStats, row.category, row.current_price, row.units_sold);
      this.updateStat(subcatStats, row.subcategory, row.current_price, row.units_sold);
      this.updateStat(brandStats, row.brand, row.current_price, row.units_sold);
      this.updateStat(seasonStats, row.season, row.current_price, row.units_sold);
      this.updateStat(materialStats, row.material, row.current_price, row.units_sold);
      this.updateStat(genderStats, row.gender, row.current_price, row.units_sold);
    }

    this.basePrice = count > 0 ? totalPrice / count : 0;
    // Ensure baseUnits is at least 1 to prevent rounding to 0 for everything
    this.baseUnits = count > 0 ? Math.max(1, totalUnits / count) : 0;

    // 2. Compute "Weights" (Splits)
    this.categoryWeights = this.computeWeights(catStats, this.basePrice, this.baseUnits);
    this.subcategoryWeights = this.computeWeights(subcatStats, this.basePrice, this.baseUnits);
    this.brandWeights = this.computeWeights(brandStats, this.basePrice, this.baseUnits);
    this.seasonWeights = this.computeWeights(seasonStats, this.basePrice, this.baseUnits);
    this.materialWeights = this.computeWeights(materialStats, this.basePrice, this.baseUnits);
    this.genderWeights = this.computeWeights(genderStats, this.basePrice, this.baseUnits);

    this.isTrained = true;

    // 3. Evaluate on Test Data
    let errorPriceSq = 0;
    let errorSalesSq = 0;
    
    for (const row of testData) {
      const pred = this.predict(row);
      // We compare our "Optimal Price" prediction against the actual price used in historical data
      errorPriceSq += Math.pow(pred.predicted_price - row.current_price, 2);
      errorSalesSq += Math.pow(pred.predicted_units - row.units_sold, 2);
    }

    const rmsePrice = Math.sqrt(errorPriceSq / testData.length);
    const rmseSales = Math.sqrt(errorSalesSq / testData.length);
    const endTime = performance.now();

    // 4. Extract Top Factors
    const topFactors = this.extractTopFactors();

    return {
      rmse_price: rmsePrice,
      rmse_sales: rmseSales,
      training_rows: trainingData.length,
      test_rows: testData.length,
      features_count: Object.keys(trainingData[0] || {}).length,
      training_time_ms: endTime - startTime,
      top_factors: topFactors
    };
  }

  private extractTopFactors() {
    // Collect all weights with their unit impact
    const allFactors: { category: string, value: string, impact_units: number }[] = [];
    
    const pushWeights = (categoryName: string, weights: CategoricalMap) => {
        Object.keys(weights).forEach(key => {
            if (key !== 'Unknown' && weights[key].unitsDiff !== 0) {
                allFactors.push({
                    category: categoryName,
                    value: key,
                    impact_units: weights[key].unitsDiff
                });
            }
        });
    };

    pushWeights('Brand', this.brandWeights);
    pushWeights('Category', this.categoryWeights);
    pushWeights('Season', this.seasonWeights);
    
    // Sort by absolute impact (positive or negative)
    allFactors.sort((a, b) => Math.abs(b.impact_units) - Math.abs(a.impact_units));
    
    return allFactors.slice(0, 6); // Return top 6
  }

  public predict(input: Partial<ProductData>): PredictionResult {
    if (!this.isTrained) throw new Error("Model not trained");

    // Helper to safe get weight, treating empty/null as 'Unknown'
    const getW = (map: CategoricalMap, key: string | undefined) => {
        if (!key || key === '' || key === 'Select...') key = 'Unknown';
        // Try exact match first, then unknown
        if (map[key]) return map[key];
        // If specific key not found, try fallback to Unknown if it exists in map
        if (map['Unknown']) return map['Unknown'];
        return undefined;
    };

    // --- STEP 1: PREDICT BASE MARKET PRICE ---
    let estimatedMarketPrice = this.basePrice;

    // Apply categorical modifiers
    const catW = getW(this.categoryWeights, input.category);
    if (catW) estimatedMarketPrice += catW.priceDiff;

    const subW = getW(this.subcategoryWeights, input.subcategory);
    if (subW) estimatedMarketPrice += subW.priceDiff;
    
    const matW = getW(this.materialWeights, input.material);
    if (matW) estimatedMarketPrice += matW.priceDiff;
    
    const genW = getW(this.genderWeights, input.gender);
    if (genW) estimatedMarketPrice += genW.priceDiff;

    // Brand Handling
    const brandW = getW(this.brandWeights, input.brand);
    let brandPremium = 0;
    if (brandW) {
        brandPremium = brandW.priceDiff;
    } else {
        brandPremium = -(estimatedMarketPrice * 0.2); 
    }
    estimatedMarketPrice += brandPremium;

    // --- CRITICAL FIX: MSRP CLAMPING ---
    // Prevent runaway brand premiums if MSRP is known
    if (input.original_price && input.original_price > 0) {
        // Clamp the "learned" price so it doesn't exceed 2.5x MSRP or fall below 0.5x MSRP
        // This handles "Burberry" outliers where training data might be skewed high
        const lowerBound = input.original_price * 0.5;
        const upperBound = input.original_price * 2.5;
        estimatedMarketPrice = Math.max(lowerBound, Math.min(upperBound, estimatedMarketPrice));
        
        // Strong blend towards MSRP (90% MSRP, 10% Learned)
        estimatedMarketPrice = (estimatedMarketPrice * 0.1) + (input.original_price * 0.9);
    }

    // Anchor to Competitor Price
    if (input.competitor_price && input.competitor_price > 0) {
        estimatedMarketPrice = (estimatedMarketPrice * 0.7) + (input.competitor_price * 0.3);
    }

    // --- STEP 2: UNIT CALCULATION LOGIC ---
    const calculateUnits = (price: number) => {
        let units = this.baseUnits;

        // Apply learned weights
        if (catW) units += catW.unitsDiff;
        if (subW) units += subW.unitsDiff;
        if (brandW) units += brandW.unitsDiff;

        // A. Inverse Price Scaling
        const pricePhysics = Math.max(0.4, Math.min(3.0, 60 / (price + 10)));
        units *= pricePhysics;

        // B. Seasonal Context
        const currentMonth = new Date().getMonth();
        const isWinter = [11, 0, 1].includes(currentMonth);
        const isSummer = [5, 6, 7].includes(currentMonth);
        let seasonalMult = 1.0;
        const s = (input.season || '').toLowerCase();
        if (s.includes('summer')) seasonalMult = isWinter ? 0.6 : (isSummer ? 1.4 : 0.9);
        else if (s.includes('winter')) seasonalMult = isWinter ? 1.4 : (isSummer ? 0.5 : 0.9);
        else if (s.includes('spring')) seasonalMult = isWinter ? 0.8 : 1.1;
        units *= seasonalMult;

        // C. Price Elasticity (Softer Curve)
        const referencePrice = input.competitor_price || estimatedMarketPrice;
        if (referencePrice > 0) {
            const priceRatio = price / referencePrice;
            if (priceRatio < 1.0) {
                units = units * Math.pow(1 + (1 - priceRatio), 2.5);
            } else {
                // Changed from -3.5 to -2.0 to prevent crash to zero
                units = units * Math.pow(priceRatio, -2.0);
            }
        }

        // D. Social Proof
        if (input.number_of_reviews) {
            const reviewBoost = 1 + (Math.log10(input.number_of_reviews + 1) * 0.4); 
            units *= reviewBoost;
        }

        // E. Quality
        if (input.rating) {
            const ratingMult = Math.pow(1.3, input.rating - 3); 
            units *= ratingMult;
        }

        // F. Promotions
        if (input.promotion_active === 1) {
            let lift = 1.4;
            if (price < 40) lift = 1.8;
            else if (price < 100) lift = 1.6;
            if (referencePrice > 0 && price < referencePrice) lift += 0.2;
            units *= lift; 
        }

        // G. Stock Availability
        if (input.stock_quantity !== undefined && input.stock_quantity >= 0) {
            if (input.stock_quantity < 5) units *= 0.5;
            units = Math.min(units, input.stock_quantity);
        }

        // Minimum 1 unit if stock > 0, ensuring we don't return 0 for valid products
        const floor = (input.stock_quantity && input.stock_quantity > 0) ? 1 : 0;
        return Math.max(floor, Math.round(units));
    };

    // --- STEP 3: PRICE OPTIMIZATION LOOP ---
    // If user didn't specify price (0), find the price that maximizes REVENUE
    let targetPrice = input.current_price && input.current_price > 0 
        ? input.current_price 
        : parseFloat(estimatedMarketPrice.toFixed(2));
    
    if ((!input.current_price || input.current_price === 0)) {
        // Test candidates: Market Estimate, MSRP, Competitor Price, and variations
        const candidates = [
            targetPrice,
            input.original_price || 0,
            input.competitor_price || 0,
            targetPrice * 0.9,
            targetPrice * 0.8,
            targetPrice * 1.1
        ].filter(p => p > 0);
        
        // Add step-down candidates if competitor price exists (undercutting)
        if (input.competitor_price) {
             candidates.push(input.competitor_price * 0.95);
        }

        let bestRevenue = -1;
        let bestPrice = targetPrice;

        for (const p of candidates) {
            // Ensure we don't sell for free or ridiculous low
            if (p < 5) continue; 
            
            const u = calculateUnits(p);
            const r = u * p;
            if (r > bestRevenue) {
                bestRevenue = r;
                bestPrice = p;
            }
        }
        targetPrice = parseFloat(bestPrice.toFixed(2));
    }

    const predUnits = calculateUnits(targetPrice);

    // --- STEP 4: SENSITIVITY ANALYSIS ---
    const sensitivityPoints = [-0.2, -0.1, 0, 0.1, 0.2];
    const price_sensitivity = sensitivityPoints.map(pct => {
        const p = parseFloat((targetPrice * (1 + pct)).toFixed(2));
        const u = calculateUnits(p);
        return {
            price: p,
            units: u,
            revenue: parseFloat((p * u).toFixed(2))
        };
    });

    return {
      predicted_price: targetPrice,
      predicted_units: predUnits,
      predicted_revenue: parseFloat((targetPrice * predUnits).toFixed(2)),
      confidence_score: this.calculateConfidence(input),
      price_sensitivity
    };
  }

  private calculateConfidence(input: Partial<ProductData>): number {
      let score = 0.5;
      if (input.brand && this.brandWeights[input.brand]) score += 0.1;
      if (input.competitor_price) score += 0.15;
      if (input.rating) score += 0.1;
      if (input.original_price) score += 0.1;
      return Math.min(0.98, score);
  }

  private updateStat(
    stats: Record<string, any>, 
    key: string, 
    price: number, 
    units: number
  ) {
    if (!key || key === 'undefined' || key === 'null') key = 'Unknown';
    if (!stats[key]) stats[key] = { priceSum: 0, unitsSum: 0, count: 0 };
    stats[key].priceSum += price;
    stats[key].unitsSum += units;
    stats[key].count += 1;
  }

  private computeWeights(stats: Record<string, any>, basePrice: number, baseUnits: number) {
    const weights: any = {};
    for (const key in stats) {
        const avgPrice = stats[key].priceSum / stats[key].count;
        const avgUnits = stats[key].unitsSum / stats[key].count;
        weights[key] = {
            priceDiff: avgPrice - basePrice,
            unitsDiff: avgUnits - baseUnits
        };
    }
    return weights;
  }

  public getUniqueValues(data: ProductData[], key: keyof ProductData): string[] {
      // Filter out 'Unknown' from the dropdown lists to make them cleaner
      return Array.from(new Set(data.map(d => String(d[key])))).filter(v => v && v !== 'Unknown').sort();
  }
}

export const modelInstance = new BrowserModel();