
import Papa from 'papaparse';
import { ProductData } from '../types';

// Fuzzy match helper: looks for exact match, case-insensitive match, or inclusion of keyword
const getValue = (row: any, keys: string[], keysOriginal: string[]): any => {
  // 1. Try exact match from our preferred list
  for (const k of keys) {
     if (row[k] !== undefined) return row[k];
  }
  
  // 2. Try case-insensitive matching against the actual row keys
  const rowKeys = Object.keys(row);
  for (const targetKey of keys) {
     const match = rowKeys.find(rk => 
       rk.toLowerCase().trim() === targetKey.toLowerCase() || 
       rk.toLowerCase().replace(/_/g, '').trim() === targetKey.toLowerCase().replace(/_/g, '')
     );
     if (match) return row[match];
  }

  // 3. Fallback: Contains check (dangerous but useful for 'Price' -> 'Current Price')
  // Only do this for specific high-value targets if needed, but let's stick to 1 & 2 for safety first.
  
  return undefined;
};

export const parseCSV = (file: File): Promise<ProductData[]> => {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true,
      complete: (results) => {
        if (results.errors.length > 0) {
          console.warn("CSV Errors:", results.errors);
        }
        
        const data = results.data.map((row: any) => {
          // Smart mapping for critical fields
          const originalPrice = getValue(row, ['original_price', 'msrp', 'originalprice', 'regular_price'], []) || 0;
          const currentPrice = getValue(row, ['current_price', 'price', 'sale_price', 'actual_price', 'retail_price'], []) || 0;
          const unitsSold = getValue(row, ['units_sold', 'units', 'sales', 'quantity', 'volume', 'qty'], []) || 0;
          const competitorPrice = getValue(row, ['competitor_price', 'comp_price', 'market_price'], []) || 0;
          const stock = getValue(row, ['stock_quantity', 'stock', 'inventory', 'quantity_on_hand'], []) || 0;
          
          return {
            ...row,
            // Numerical / Metrics
            original_price: Number(originalPrice),
            current_price: Number(currentPrice),
            units_sold: Number(unitsSold),
            competitor_price: Number(competitorPrice),
            rating: Number(getValue(row, ['rating', 'stars', 'score'], []) || 0),
            number_of_reviews: Number(getValue(row, ['number_of_reviews', 'reviews', 'review_count'], []) || 0),
            stock_quantity: Number(stock),
            promotion_active: Number(getValue(row, ['promotion_active', 'promotion', 'is_promo', 'promo'], []) || 0),

            // Categorical (Normalize to Title Case or similar if desired, but String cast is safest)
            brand: String(getValue(row, ['brand', 'manufacturer', 'make'], []) || 'Unknown'),
            category: String(getValue(row, ['category', 'department', 'type'], []) || 'Unknown'),
            subcategory: String(getValue(row, ['subcategory', 'sub_category', 'product_type'], []) || 'Unknown'),
            season: String(getValue(row, ['season', 'seasonality'], []) || 'Unknown'),
            gender: String(getValue(row, ['gender', 'sex', 'demographic'], []) || 'Unknown'),
            material: String(getValue(row, ['material', 'fabric', 'composition'], []) || 'Unknown'),
            color: String(getValue(row, ['color', 'colour'], []) || 'Unknown'),
          } as ProductData;
        });

        resolve(data);
      },
      error: (error) => {
        reject(error);
      }
    });
  });
};

export const exportToCSV = (data: any[], filename: string) => {
  const csv = Papa.unparse(data);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};
